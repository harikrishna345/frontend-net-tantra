export enum Roles {
  ADMIN = 'ADMIN',
  BUYER = 'BUYER',
  SELLER = 'SELLER',
  DATA_MANAGER = 'DATA MANAGER',
}
