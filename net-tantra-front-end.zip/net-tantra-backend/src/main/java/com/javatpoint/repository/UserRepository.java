package com.javatpoint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.javatpoint.model.User;

public interface UserRepository extends JpaRepository<User,Integer> {
    User findByUserName(String username);
	//User findByEmail(String email);
    List<User> findAll();
    
    @Query("Select u from User u WHERE u.email=:email")
    User findByEmail1(@Param("email") String email);
    
    @Query(value="select * from user_tbl a where a.u_email= :email", nativeQuery=true)
    List<User> getAuthorsByFirstName(String email);
	boolean existsByEmail(String email);

}