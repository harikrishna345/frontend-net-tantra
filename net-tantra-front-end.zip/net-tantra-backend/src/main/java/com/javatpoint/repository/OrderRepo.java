package com.javatpoint.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.javatpoint.model.User;
import com.javatpoint.model.Order;

public interface OrderRepo extends JpaRepository<Order,Integer> {
	//order findByUserName(String email);
	//User findByEmail(String email);
    List<Order> findAll();
    
    @Query(value="select * from orders_tbl a where a.o_user_id= :id", nativeQuery=true)
    List<Order> getById(int id);

	Optional<Order> findById(int id);

    
}
