package com.javatpoint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


import com.javatpoint.model.User;
import com.javatpoint.model.Order;
import com.javatpoint.repository.OrderRepo;
import com.javatpoint.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	@Autowired
	private UserRepository repository;

	@Autowired
	private OrderRepo repo;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = repository.findByEmail1(email);
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				new ArrayList<>());

	}

	public void saveOrUpdate(User user) {
		repository.save(user);
	}

	public void saveOrder(Order ord) {
		repo.save(ord);
	}

	public boolean checkUser(User user) {

		return !repository.existsByEmail(user.getEmail());

	}

	public List<User> getUserMail(String email) {
		// TODO Auto-generated method stub
		return repository.getAuthorsByFirstName(email);
	}

	public List<Order> getById(int id) {
		// TODO Auto-generated method stub
		return repo.getById(id);
	}

	public List<Order> getOrdersList() {
		return repo.findAll();
	}

	

	public Order update(Order ord, int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).map(address -> {
			address.setStatus(ord.getStatus());
			return repo.save(address);
		}).orElseGet(() -> {
			return repo.save(ord);
		});
	}
}