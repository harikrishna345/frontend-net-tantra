package com.javatpoint.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javatpoint.model.AuthRequest;
import com.javatpoint.model.Order;
import com.javatpoint.model.User;
import com.javatpoint.repository.OrderRepo;
import com.javatpoint.service.CustomUserDetailsService;
import com.javatpoint.util.JwtUtil;

@RestController
public class WelcomeController {

	@Autowired
	CustomUserDetailsService userService;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private OrderRepo repo;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@CrossOrigin(origins = "http://localhost:4200")

	@GetMapping("/")
	public ResponseEntity<String> welcome() {
		// return "Wel";
		return ResponseEntity.ok("Wel");
	}

	@GetMapping("/user")
	private List<User> getBooks(@RequestParam("email") String email) {
		return userService.getUserMail(email);
	}

	@PostMapping("/authenticate")
	public ResponseEntity<HashMap<String, String>> generateToken(@RequestBody AuthRequest authRequest)
			throws Exception {
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));
		} catch (Exception ex) {
			// throw new Exception("inavalid username/password");
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("status", "0");
			map.put("error", "Inavalid username/password");
			return ResponseEntity.ok(map);
		}
		// return jwtUtil.generateToken(authRequest.getUserName());
		// return authRequest.getEmail();
		// return ResponseEntity.ok(jwtUtil.generateToken(authRequest.getUserName()));
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("status", "1");
		map.put("token", jwtUtil.generateToken(authRequest.getEmail()));
		map.put("email", authRequest.getEmail());
		// return map;
		return ResponseEntity.ok(map);

	}

	@PostMapping("/signup")
	private int saveUser(@RequestBody User user) {
		userService.saveOrUpdate(user);
		return user.getId();
	}

	@PostMapping("/order")
	private int saveOrder(@RequestBody Order ord) {
		userService.saveOrder(ord);
		return ord.getId();
	}

	@PostMapping("/verifyUser")
	private boolean checkUser(@RequestBody User user) {
		return userService.checkUser(user);

	}

	@GetMapping("/user-orders-list")
	private List<Order> orderList(@RequestParam("id") int id) {
		return userService.getById(id);
	}

	@GetMapping("/orders-admin-list")
	public List<Order> getAllList() {
		return userService.getOrdersList();
	}

	@PutMapping("/order-edit/{id}")
	private  Order updateOrder(@RequestBody Order ord,@PathVariable int id) {
		//return userService.getOrdersList();
		return userService.update(ord, id);

	}
}
