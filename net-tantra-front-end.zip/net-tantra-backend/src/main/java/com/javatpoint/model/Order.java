package com.javatpoint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "orders_tbl")
public class Order {
	 @Id
	    @Column(name="o_id")
	    private int id;
	    
	    @Column(name="o_service_type")
	    private String serviceType;
	    
	    @Column(name="o_date")
	    private String date;
	    
	    @Column(name="o_email")
	    private String email;
	    
	    @Column(name="o_user_id")
	    private String userId;
	    
	    @Column(name="o_address")
	    private String addres;
	    
	    @Column(name="o_phone")
	    private String phone;
	    
	    @Column(name="o_slot")
	    private String slot;
	    
	    @Column(name="o_owner_name")
	    private String ownerName;
	    
	    @Column(name="o_created_at")
	    private String createdAt;
	    
	    @Column(name="o_update_at")
	    private String updatedAt;
	    
	    @Column(name="o_status")
	    private String status;
	    
	    @Column(name="o_exp_delivery_date")
	    private String expDelDate;
}
