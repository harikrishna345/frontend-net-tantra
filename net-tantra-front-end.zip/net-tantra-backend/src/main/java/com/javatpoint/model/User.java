package com.javatpoint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_tbl")
public class User {
    @Id
    @Column(name="u_id")
    private int id;
    
    @Column(name="u_user_name")
    private String userName;
    
    @Column(name="u_password")
    @JsonProperty(access = Access.WRITE_ONLY)
    private String password;
    
    @Column(name="u_email",unique = true)
    private String email;
    
    @Column(name="u_role")
    private String userRole;
}
